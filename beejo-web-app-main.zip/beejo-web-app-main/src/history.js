import { createBrowserHistory } from 'history';
// Add history in Google Analytics
const history = createBrowserHistory();
export default history;
