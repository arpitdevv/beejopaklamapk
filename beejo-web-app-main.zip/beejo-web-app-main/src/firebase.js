import firebase from 'firebase';

const firebaseConfig = {
  apiKey: 'AIzaSyC8guwWZ4Sy7MlGVGEOZByeq-9P7j7lBsw',
  authDomain: 'beejo-app.firebaseapp.com',
  projectId: 'beejo-app',
  storageBucket: 'beejo-app.appspot.com',
  messagingSenderId: '511196809308',
  appId: '1:511196809308:web:1b586fd36d32c7a26afe99',
  measurementId: 'G-Y48WDY528Z'
};

firebase.initializeApp(firebaseConfig);

export default firebase;
