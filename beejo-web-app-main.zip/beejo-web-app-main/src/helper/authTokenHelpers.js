import axios from 'axios';
import jwt_decode from 'jwt-decode';
import UserPreferenceSingleton from './UserPreferenceSingleton';

export const setupToken = () => {
  const token = UserPreferenceSingleton.getInstance().getUserToken();

  if (token) {
    const decoded = jwt_decode(token);
    const currentTime = Date.now() / 1000;
    if (decoded.exp > currentTime) {
      setAuthToken(token);
      return token;
    }
  }
  return false; // if no token or expired token, return false
};

export const validateRefreshToken = () => {
  const authData = UserPreferenceSingleton.getInstance().getUserToken();

  if (authData) {
    const decoded = jwt_decode(authData.refresh_token);
    const currentTime = Date.now() / 1000;
    if (decoded.exp > currentTime) {
      return authData.refresh_token;
    }
  }
  return false; // if no token or expired token, return false
};

export const saveToken = (access_token) => {
  setAuthToken(access_token);
  UserPreferenceSingleton.getInstance().setUserToken(access_token);
};

export const clearToken = () => {
  UserPreferenceSingleton.getInstance().clearStoredUserData();
  clearAuthToken();
};

// header methods
const setAuthToken = (token) => {
  try {
    axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
  } catch (e) {
    console.log('Error while settup token', e);
  }
};

const clearAuthToken = () => {
  delete axios.defaults.headers.common['Authorization'];
};
