let singleton;
const singletonEnforcer = Symbol();
const parseDataFile = (defaults) => {
  try {
    const settings = localStorage.getItem('UserPreferences');
    if (settings) return JSON.parse(settings);
    return {};
  } catch (error) {
    return defaults;
  }
};

const containsKey = (obj, key) => ({}.hasOwnProperty.call(obj || {}, key));

class UserPreferences {
  constructor(opts) {
    this.defaults = opts.defaults;
    this.data = parseDataFile(opts.defaults);
  }

  get(key, defaultValue) {
    if (containsKey(this.data, key)) {
      return this.data[key];
    }
    return defaultValue;
  }

  save(settings) {
    localStorage.setItem('UserPreferences', JSON.stringify(settings));
  }

  set(key, value) {
    this.data = parseDataFile(this.defaults);
    this.data[key] = value;
    this.save(this.data);
  }

  remove(key) {
    delete this.data[key];
    this.save(this.data);
  }

  parseDataFile() {
    this.data = parseDataFile(this.defaults);
  }

  contains(key) {
    return Object.prototype.hasOwnProperty.call(this.data, key);
  }
}
export default class UserPreferenceSingleton {
  static get ACCESS_TOKEN() {
    return 'access_tokens';
  }

  static get DISPLAY_NAME() {
    return 'display_name';
  }

  constructor(enforcer) {
    if (enforcer !== singletonEnforcer) throw new Error('Cannot construct singleton');

    this.userPreferences = new UserPreferences({
      configName: 'user-preferences',
      defaults: {
        windowBounds: { width: 800, height: 600 }
      }
    });
  }

  static getInstance() {
    if (!singleton) {
      singleton = new UserPreferenceSingleton(singletonEnforcer);
    }
    return singleton;
  }

  getUserToken() {
    return this.userPreferences.get(UserPreferenceSingleton.ACCESS_TOKEN, undefined);
  }

  setUserToken(value) {
    return this.userPreferences.set(UserPreferenceSingleton.ACCESS_TOKEN, value);
  }

  getDisplayName() {
    return this.userPreferences.get(UserPreferenceSingleton.DISPLAY_NAME, undefined);
  }

  setDisplayName(value) {
    return this.userPreferences.set(UserPreferenceSingleton.DISPLAY_NAME, value);
  }

  get(key, defaultValue = null) {
    return this.userPreferences.get(key, defaultValue);
  }

  set(key, value) {
    this.userPreferences.set(key, value);
  }

  getServerUrl() {
    return this.userPreferences.get(UserPreferenceSingleton.SERVER_URL, null);
  }

  clearStoredUserData() {
    this.userPreferences.remove(UserPreferenceSingleton.ACCESS_TOKEN);
    this.userPreferences.remove(UserPreferenceSingleton.DISPLAY_NAME);
  }
}
