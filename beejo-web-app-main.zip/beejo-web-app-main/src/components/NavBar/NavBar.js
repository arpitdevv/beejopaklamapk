import React, { Component } from 'react';
import { connect } from 'react-redux';
import styled from 'styled-components';
import { NavLink } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Menu from '@material-ui/core/Menu';
import { StylesProvider } from '@material-ui/core';
import { Accordion } from '@material-ui/core';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import { ReactComponent as HomeIcon } from '../../assets/images/svg/home.svg';
import { ReactComponent as InventoryLogo } from '../../assets/images/svg/inventory.svg';
// import Avtar from '../Avtar/Avtar';
import LogoIcon from '../../../src/assets/images/beejIcon.png';

const LeftBar = styled.div`
  height: 100vh;
  width: 280px;
  float: left;
  background-color: #f4f6f8;
  padding: 20px 16px;
  border: 1px solid #e3e8ee;
  position: relative;
`;
const NavTop = styled.div`
  height: calc(100% - 60px);
  overflow: auto;
  padding-bottom: 50px;
`;
const MembershipBox = styled.div`
  text-align: center;
  margin-top: 10px;
  margin-bottom: 28px;
`;
const NavBottom = styled.div`
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 10px;
  background-color: #f4f6f8;
`;
const AccordionWrap = styled(Accordion)`
  background-color: transparent;
  margin: 0px;
  box-shadow: none;
  padding: 0px;
  &.Mui-expanded {
    margin: 0;
    svg {
      path {
        fill: #256937;
      }
    }
  }
  &.MuiAccordion-root::before {
    background-color: transparent;
  }
`;
const AccordionSummaryWrap = styled(AccordionSummary)`
  display: flex;
  align-items: center;
  &.Mui-expanded {
    min-height: 48px;
  }
  .MuiAccordionSummary-content {
    margin: 0;
    padding: 8px 14px;
    &.Mui-expanded {
      margin: 0;
      padding: 8px 14px;
      background: #e3e8ee;
      border-radius: 6px;
    }
    :hover {
      background: #e3e8ee;
      border-radius: 6px;
      padding: 8px 14px;
    }
  }
  &.MuiAccordionSummary-root {
    padding: 0;
  }
`;
const TypographyText = styled(Typography)`
    margin-left: 18px;
    font-family: Inter;
    font-style: normal;
    font-weight: 500;
    font-size: 15px;
    color: #1A1F36;
    ${AccordionWrap}.Mui-expanded &{
        color: #256937;
        }
    }
`;
const TypographySubText = styled(Typography)`
  font-family: Inter;
  font-style: normal;
  font-weight: normal;
  font-size: 15px;
  cursor: pointer;
  &:hover {
    text-decoration: underline;
  }
`;
const AccordionDetailsList = styled(AccordionDetails)`
  margin-left: 30px;
  padding: 0;
  a {
    padding: 10px 16px;
    width: 100%;
    font-family: Inter;
    font-style: normal;
    font-weight: 500;
    font-size: 15px;
    line-height: 18px;
    color: #4f566b;
    margin: 4px 0;
    :hover {
      background: #e3e8ee;
      border-radius: 6px;
      text-decoration: none;
      color: #4f566b;
    }
    p {
      text-decoration: none;
      :hover {
        text-decoration: none;
      }
    }
  }
`;
const MenuItemLink = styled(NavLink)`
  &.active_menu {
    background: #e3e8ee;
    border-radius: 6px;
    font-family: Inter;
    font-style: normal;
    font-weight: 500;
    font-size: 15px;
    line-height: 40px;
    color: #1a1f36;
    :hover {
      color: #1a1f36;
    }
  }
`;
const UserMenu = styled.div`
  display: flex;
  align-items: center;
  margin-top: auto;
  border-radius: 6px;
  padding: 10px;
`;
const UserMenuBlock = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
`;
const Image = styled.img``;
const UserDetail = styled.div``;
const UserName = styled.h4`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  color: #1a1f36;
  margin: 0;
`;
const UserCaption = styled.span`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 13px;
  line-height: 16px;
  color: #8792a2;
`;
const ProfileNameBlock = styled.div`
  border-bottom: 1px solid #e3e8ee;
  padding-bottom: 16px;
  margin-bottom: 16px;
`;
const ProfileName = styled.h2`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  line-height: 18px;
  color: #1a1f36;
  margin: 0;
  padding-bottom: 4px;
`;
const ProfileEmail = styled.span`
  font-family: Inter;
  font-style: normal;
  font-weight: normal;
  font-size: 13px;
  line-height: 16px;
  color: #4f566b;
`;
const Menulist = styled.span`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 13px;
  line-height: 16px;
  color: #4f566b;
  display: block;
  padding-bottom: 10px;
  cursor: pointer;
`;

const StyledMenu = withStyles({
  paper: {
    border: '1px solid #d3d4d5',
    padding: '16px 16px 6px 16px',
    background: '#FFFFFF',
    boxShadow: '0px 0px 1px rgba(0, 0, 0, 0.3), 0px 3px 10px rgba(0, 0, 0, 0.1)',
    borderRadius: '6px',
    width: '260px',
    marginBottom: '10px',
    marginLeft: '-7px'
  }
})((props) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: 'top',
      horizontal: 'left'
    }}
    transformOrigin={{
      vertical: 'bottom',
      horizontal: 'left'
    }}
    {...props}
  />
));

class NavBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: this.props.expanded || 'HOME',
      anchorEl: null,
      isOpenProfileMenu: false
    };
  }

  handleChange = (accordion) => (isExpanded) => {
    let expanded;
    isExpanded ? (expanded = accordion) : (expanded = false);
    this.setState({ expanded });
  };

  onClickLogout = async () => {
    this.props.history.push('/login');
  };

  openProfileMenu = (e) => {
    this.setState({ isOpenProfileMenu: true, anchorEl: e.currentTarget });
  };

  closeProfileMenu = (e) => {
    this.setState({ isOpenProfileMenu: false, anchorEl: null });
  };

  render() {
    const { expanded, isOpenProfileMenu, anchorEl } = this.state;

    return (
      <StylesProvider injectFirst>
        <LeftBar>
          <NavTop>
            <MembershipBox>
              <Image src={LogoIcon} />
            </MembershipBox>
            <AccordionWrap expanded={expanded === 'HOME'} onChange={this.handleChange('HOME')}>
              <MenuItemLink to={'/home'}>
                <AccordionSummaryWrap>
                  <HomeIcon />
                  <TypographyText>Home</TypographyText>
                </AccordionSummaryWrap>
              </MenuItemLink>
            </AccordionWrap>
            <AccordionWrap expanded={expanded === 'PRODUCT'} onChange={this.handleChange('PRODUCT')}>
              <MenuItemLink to={'/addproduct'} activeClassName='active_menu'>
                <AccordionSummaryWrap>
                  <InventoryLogo />
                  <TypographyText>Product</TypographyText>
                </AccordionSummaryWrap>
              </MenuItemLink>
              <AccordionDetailsList>
                <MenuItemLink to={'/addproduct'} activeClassName='active_menu'>
                  <TypographySubText>Add Product</TypographySubText>
                </MenuItemLink>
              </AccordionDetailsList>
              <AccordionDetailsList>
                <MenuItemLink to={'/categorylist'} activeClassName='active_menu'>
                  <TypographySubText>Category List</TypographySubText>
                </MenuItemLink>
              </AccordionDetailsList>
            </AccordionWrap>
          </NavTop>
          <NavBottom>
            <div>
              <UserMenu onClick={this.openProfileMenu}>
                <UserMenuBlock onClick={this.handleClick}>
                  {/* <Avtar imgSrc={user.avatar} name={displayName} size={38} /> */}
                  <UserDetail>
                    <UserName>{'displayName'}</UserName>
                    <UserCaption>{'displayCompany'}</UserCaption>
                  </UserDetail>
                </UserMenuBlock>
              </UserMenu>
              <StyledMenu
                id='customized-menu'
                anchorEl={anchorEl}
                keepMounted
                open={isOpenProfileMenu}
                onClose={this.closeProfileMenu}>
                <ProfileNameBlock>
                  <ProfileName>{'displayName'}</ProfileName>
                  <ProfileEmail>{'displayEmail'}</ProfileEmail>
                </ProfileNameBlock>
                <MenuItemLink to={'/my-profile'}>
                  <Menulist>My Profile</Menulist>
                </MenuItemLink>
                <Menulist onClick={this.onClickLogout}>Logout</Menulist>
              </StyledMenu>
            </div>
          </NavBottom>
        </LeftBar>
      </StylesProvider>
    );
  }
}
const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(NavBar);
