import React, { Component } from 'react';
import styled, { css } from 'styled-components';

const TextInput = styled.input`
  padding: 11px 16px;
  display: inline-block;
  border: 1px solid #e3e8ee;
  width: 100%;
  outline: 0;
  background: #ffffff;
  box-sizing: border-box;
  border-radius: 5px;
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  line-height: 18px;
  margin-bottom: 10px;
  color: rgba(26, 31, 54, 1);
  transition: 0.1s all ease;
  &::placeholder {
    color: rgba(26, 31, 54, 0.25);
  }
  ${(props) =>
    props.filtermodal &&
    css`
      margin: 10px 0px 0px 0px;
      padding: 9px 12px;
      font-family: Inter;
      font-style: normal;
      font-weight: 500;
      font-size: 15px;
      color: #1a1f36;
    `}
  ${(props) =>
    props.newinventory &&
    css`
      padding: 11px 16px;
    `}
    ${(props) =>
    props.Productinput &&
    css`
      padding: 12px 16px;
      margin-bottom: 16px;
    `}
    ${(props) =>
    props.borderremoveinput &&
    css`
      border: none;
      :hover {
        border: none !important;
      }
      :focus {
        border: none !important;
        outline: 0 !important;
      }
      :active {
        border: none !important;
      }
    `}
    ${(props) =>
    props.transactionitem &&
    css`
      width: 282px;
      height: 29px;
      font-family: Inter;
      font-style: normal;
      font-weight: 500;
      font-size: 13px;
      line-height: 16px;
      color: #4f566b;
    `}
    :hover {
    border: 1px solid #c5c8cd;
  }
  :focus {
    border: 1px solid #c5c8cd;
    outline: 0;
  }
  :active {
    border: 1px solid #c5c8cd;
  }
`;
class Input extends Component {
  render() {
    const { type, disabled, placeholder, autoFocus, value, onChange, onKeyDown, min, max } = this.props;
    return (
      <>
        <TextInput
          min={min}
          max={max}
          {...this.props}
          type={type}
          onChange={onChange}
          disabled={disabled}
          placeholder={placeholder}
          autoFocus={autoFocus}
          value={value}
          onKeyDown={onKeyDown}
        />
      </>
    );
  }
}

export default Input;
