import React, { Component } from 'react';
import classNames from 'classnames';
import styled, { css } from 'styled-components';
import Warning from '../../assets/images/svg/warning.svg';
import Checkmark from '../../assets/images/svg/checkmark.svg';

const MessageWrap = styled.div`
  font-family: Inter;
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 16px;
  padding: 9px 44px;
  width: 100%;
  ${(props) =>
    props.small &&
    css`
      width: 62%;
      padding: 6px 44px;
    `}
  &.successBox {
    color: #92d048;
    background: #f2ffe3;
    border: 1px solid #92d048;
    border-radius: 5px;
    background-image: url(${Checkmark});
    background-repeat: no-repeat;
    background-position: 12px;
  }
  &.errorBox {
    color: #ff4b4b;
    background: #ffebeb;
    border: 1px solid #ff4b4b;
    border-radius: 5px;
    background-image: url(${Warning});
    background-repeat: no-repeat;
    background-position: 12px;
  }
`;
const Paragraph = styled.p`
  margin: 0;
  white-space: pre-wrap;
`;

class Message extends Component {
  render() {
    const { text, type } = this.props;
    const isSuccess = type === 'success';
    return (
      <MessageWrap {...this.props} className={classNames('statusCover', isSuccess ? 'successBox' : 'errorBox')}>
        <Paragraph className='statusText'>{text === undefined ? (isSuccess ? 'Success' : 'Error') : text}</Paragraph>
      </MessageWrap>
    );
  }
}

export default Message;
