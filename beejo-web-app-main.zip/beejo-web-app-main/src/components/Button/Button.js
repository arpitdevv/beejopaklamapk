import React, { Component } from 'react';
import styled, { css } from 'styled-components';

const PrimaryButton = styled.button`
  font-family: 'Inter', sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 22px;
  text-align: center;
  padding: 12px 24px;
  cursor: pointer;
  border-radius: 5px;
  outline: none;
  user-select: none;
  text-transform: capitalize;
  border: 1px solid rgba(0, 0, 0, 0.1);
  box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.12);
  background: #029154;
  color: #ffffff;
  transition: 0.3s all ease;

  ${(props) =>
    props.fullwidth &&
    css`
      width: 100%;
      padding: 4px 0;
      margin-top: 10px;
    `}

  ${(props) =>
    props.small &&
    css`
      padding: 4px 14px;
      margin: 0px 15px 0px 7.5px;
    `}
  
  ${(props) =>
    props.apply &&
    css`
      padding: 4px 15px;
      margin: 0px 7px 0px 0px;
    `}
  
  ${(props) =>
    props.clear &&
    css`
      padding: 4px 15px;
      margin: 0px 0px 0px 7px;
      color: #1a1f36;
      background: #ffffff;
    `}
  
  ${(props) =>
    props.createbtn &&
    css`
      color: #1a1f36;
      background: #ffffff;
      padding: 4px 14px;
      box-sizing: border-box;
      :hover {
        :hover {
          background: #2541d5;
          border: 1px solid rgba(0, 0, 0, 0.1);
          box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.12);
color:#FFFFFF;
        transition: 0.3s all ease;
      }
      
    `} &:disabled {
    opacity: 0.6;
  }
  :hover {
    background: #256937;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.12);
    transition: 0.3s all ease;
  }
`;
const SecondaryButton = styled(PrimaryButton)`
  // border: 1px solid ;
  // background: ;
  // color: ;

  ${(props) =>
    props.fullwidth &&
    css`
      width: 100%;
    `}
`;

class Button extends Component {
  render() {
    const { title, type, disabled, isPrimary, onClick } = this.props;
    return (
      <>
        {isPrimary === true && (
          <PrimaryButton {...this.props} type={type} disabled={disabled} onClick={onClick}>
            {title}
          </PrimaryButton>
        )}
        {isPrimary === false && (
          <SecondaryButton {...this.props} type={type} disabled={disabled} onClick={onClick}>
            {title}
          </SecondaryButton>
        )}
      </>
    );
  }
}

export default Button;
