import * as Actions from './../actions/types';

const initialState = {
  resError: '',
  resSuccess: '',
  itemResSuccess: '',
  itemResError: ''
};

export const messageReducer = (state = initialState, action) => {
  switch (action.type) {
    case Actions.SET_RES_SUCCESS_MSG:
      return {
        ...state,
        resSuccess: action.payload
      };
    case Actions.SET_RES_ERROR_MSG:
      return {
        ...state,
        resError: action.payload
      };
    case Actions.SET_ITEM_ERROR_MSG:
      return {
        ...state,
        itemResError: action.payload
      };
    case Actions.SET_ITEM_SUCESS_MSG:
      return {
        ...state,
        itemResSuccess: action.payload
      };
    case Actions.CLEAR_RES_MSG:
      return initialState;
    default:
      return state;
  }
};
