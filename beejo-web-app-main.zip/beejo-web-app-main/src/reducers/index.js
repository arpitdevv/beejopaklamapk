import { combineReducers } from 'redux';
import { authReducer } from './authReducer';
import { messageReducer } from './messageReducer';
import { productReducer } from './productReducer';

const appReducer = combineReducers({
  message: messageReducer,
  auth: authReducer,
  product: productReducer
});

export default appReducer;
