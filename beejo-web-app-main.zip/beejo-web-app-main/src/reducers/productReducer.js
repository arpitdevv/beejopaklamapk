import * as actions from '../../src/actions/types';

const initialState = {
  loading: false,
  resError: '',
  resSuccess: '',
  categoryList: undefined
};

export const productReducer = (state = JSON.parse(JSON.stringify(initialState)), action) => {
  switch (action.type) {
    case actions.SET_PRODUCT_LOADER:
      return {
        ...state,
        loading: action.payload
      };
    case actions.SET_CATEGORY_LIST:
      return {
        ...state,
        categoryList: action.payload
      };
    case actions.GET_PRODUCT_RES_ERROR:
      return {
        ...state,
        resError: action.payload
      };
    case actions.GET_PRODUCT_RES_SUCCESS:
      return {
        ...state,
        resSuccess: action.payload
      };
    case actions.CLEAR_PRODUCT_RES_MSG:
      return {
        ...state,
        resSuccess: '',
        resError: ''
      };
    case actions.CLEAR_PRODUCT_DATA:
      return initialState;
    default:
      return state;
  }
};
