export const REACT_APP_ENV = process.env.REACT_APP_ENV;
export const REACT_APP_APIURL = process.env.REACT_APP_APIURL;
