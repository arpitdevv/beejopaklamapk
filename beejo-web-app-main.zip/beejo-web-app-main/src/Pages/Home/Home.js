import React, { Component } from 'react';
import styled from 'styled-components';
import NavBar from '../../components/NavBar/NavBar';
import { ReactComponent as WorkProgressIcon } from '../../assets/images/svg/progress.svg';

const WorkInBlock = styled.div`
  align-items: center;
  justify-content: center;
  display: flex;
  height: 100%;
`;
const MinContact = styled.div``;
const ItemRight = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  height: calc(100vh - 320px);
`;
const Text = styled.h1`
  margin-top: 30px;
  margin-bottom: 0;
`;
class Home extends Component {
  render() {
    return (
      <>
        <NavBar expanded={'HOME'} />
        <WorkInBlock>
          <MinContact>
            <ItemRight>
              <WorkProgressIcon />
              <Text>Work in Progress</Text>
            </ItemRight>
          </MinContact>
        </WorkInBlock>
      </>
    );
  }
}

export default Home;
