import React from 'react';

const PageNotFound = ({ location }) => (
  <div>
    No match for <code>{location.pathname}</code>
  </div>
);

export default PageNotFound;
