import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import classNames from 'classnames';
import { connect } from 'react-redux';
import { clearResponseMessage, setErrorMessage } from '../../../actions/messageActions';
import Button from '../../../components/Button/Button';
import Input from '../../../components/Input/Input';
import LogoIcon from '../../../../src/assets/images/beejIcon.png';
import Message from '../../../components/Message';
import { loadRequiredData } from '../../../services/baseService';
import { MembershipBody, MembershipWrap, MembershipBox, LoginForm, LoginH2, MemberLogin, ButtonWrap } from './styles';
import firebase from '../../../firebase';
const Image = styled.img``;
class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      number: '+91',
      password: '',
      loading: false,
      otp: '000000'
    };
  }

  componentWillUnmount() {
    this.props.clearResponseMessage();
  }

  onChangeNumber = (e) => {
    this.setState({ number: e.target.value });
  };

  setUpRecaptcha = () => {
    window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
      size: 'invisible',
      callback: (response) => {
        console.log('responce at reacaptcha', response);
        // reCAPTCHA solved, allow signInWithPhoneNumber.
        this.onSignInSubmit();
      }
    });
  };

  onSignInSubmit = (event) => {
    event.preventDefault();
    this.setUpRecaptcha();
    const phoneNumber = '+917405884958';
    const appVerifier = window.recaptchaVerifier;
    firebase
      .auth()
      .signInWithPhoneNumber(phoneNumber, appVerifier)
      .then((confirmationResult) => {
        // SMS sent. Prompt user to type the code from the message, then sign the
        // user in with confirmationResult.confirm(code).
        window.confirmationResult = confirmationResult;
        const code = '000000';
        const token = firebase.auth().currentUser.getIdToken(true);
        console.log('tokentoken', token);
        confirmationResult
          .confirm(code)
          .then((result) => {
            // User signed in successfully.
            console.log('result', result);
            // ...
          })
          .catch((error) => {
            console.log('error', error);
            // User couldn't sign in (bad verification code?)
            // ...
          });
        // ...
      })
      .catch((error) => {
        // Error; SMS not sent
        // ...
      });
  };
  //   onSubmit = async (e) => {
  //     e.preventDefault();
  //     const { number } = this.state;

  renderErrors() {
    const { resError } = this.props.message;

    if (resError) {
      return <Message text={resError} type={'error'} />;
    }
  }

  // onSubmit = () => {
  //   this.props.history.push('/');
  // };

  renderSuccess() {
    const { resSuccess } = this.props.message;
    if (resSuccess) {
      return <Message text={resSuccess} type={'success'} />;
    }
  }

  render() {
    const { number } = this.state;
    const { loading } = this.props.auth;
    return (
      <MembershipBody>
        <MembershipWrap>
          <MembershipBox>
            <Image src={LogoIcon} />
          </MembershipBox>
          <LoginForm onSubmit={this.onSignInSubmit}>
            <div id='recaptcha-container'></div>
            <MemberLogin>
              <LoginH2>Login</LoginH2>
              <Input placeholder='Mobile No' onChange={this.onChangeNumber} value={number} type='number' />
              <ButtonWrap className={classNames('btn-save-loading', { loading: loading })}>
                <Button fullwidth isPrimary={true} title='Login' disabled={loading} />
              </ButtonWrap>
            </MemberLogin>
            {this.renderErrors()}
            {this.renderSuccess()}
          </LoginForm>
          {/* <PasswordDiv>
            <ForgotPassWord onClick={this.handleForgotPassword} disabled={loading}>
              Forgot Password?
            </ForgotPassWord>
          </PasswordDiv>
          <CreateAccount>
            <Button
              createbtn
              isPrimary={false}
              title='Create New Account'
              onClick={this.handleCreateNewAccount}
              disabled={loading}
            />
          </CreateAccount> */}
        </MembershipWrap>
      </MembershipBody>
    );
  }
}

Login.propTypes = {
  auth: PropTypes.object.isRequired
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  message: state.message
});

export default connect(mapStateToProps, {
  clearResponseMessage,
  setErrorMessage,
  loadRequiredData
})(Login);
