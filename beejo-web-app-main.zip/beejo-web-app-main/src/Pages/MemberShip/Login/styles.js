import styled from 'styled-components';

const MembershipBody = styled.div`
  background-color: #f4f6f8;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
`;
const MembershipWrap = styled.div`
  background-color: #ffffff;
  max-width: 400px;
  width: 100%;
  margin: auto;
  padding: 50px 0;
  border-radius: 3px;
`;
const MembershipBox = styled.div`
  text-align: center;
`;
const LoginForm = styled.form`
  padding: 0 50px 0px 50px;
  text-align: center;
`;
const MemberLogin = styled.div`
  text-align: center;
  button {
    line-height: 16px;
    padding: 7px;
  }
`;
const LoginH2 = styled.h2`
  font-family: Inter;
  font-style: normal;
  font-weight: bold;
  font-size: 25px;
  line-height: 30px;
  text-align: center;
  color: #1a1f36;
  margin: 30px 0;
`;
const PasswordDiv = styled.div`
  text-align: center;
`;
const ForgotPassWord = styled.span`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 13px;
  line-height: 16px;
  color: #4f566b;
  display: inline-block;
  text-align: center;
  margin: 30px 0;
  cursor: pointer;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`;
const CreateAccount = styled.div`
  text-align: center;
`;
const Error = styled.div`
  color: rgba(255, 75, 75, 1);
  text-align: left;
  margin-top: -9px;
  margin-bottom: 5px;
`;
const ButtonWrap = styled.div`
  margin-bottom: 10px;
`;
export {
  MembershipBody,
  MembershipWrap,
  MembershipBox,
  LoginForm,
  MemberLogin,
  LoginH2,
  PasswordDiv,
  ForgotPassWord,
  CreateAccount,
  Error,
  ButtonWrap
};
