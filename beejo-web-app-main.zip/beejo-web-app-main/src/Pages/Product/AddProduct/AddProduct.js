import React, { Component } from 'react';
import styled, { css } from 'styled-components';
import NavBar from '../../../components/NavBar/NavBar';
import Input from '../../../components/Input/Input';
import classNames from 'classnames';
import Button from '../../../components/Button/Button';
import { ReactComponent as RemoveIcon } from '../../../assets/images/svg/removeicon.svg';
import LogoIcon from '../../../../src/assets/images/beejIcon.png';
import { connect } from 'react-redux';
import { addProduct } from '../../../services/productService';
import Message from '../../../components/Message';
import { clearResponseMessage } from '../../../actions/messageActions';

const InputBlockWrap = styled.div`
  width: 100%;
  padding: 0 10px;
  ${(props) =>
    props.formboxone &&
    css`
      padding-left: 0px;
    `}
  ${(props) =>
    props.formboxotwo &&
    css`
      padding-right: 0px;
    `}
`;
const InputBlock = styled.div`
  margin-bottom: 20px;
  input {
    margin-bottom: 0px;
  }
  input::placeholder {
    font-family: Inter;
    font-style: normal;
    font-weight: 500;
    font-size: 15px;
    line-height: 18px;
    color: rgba(26, 31, 54, 0.25);
  }
`;
const LabelForm = styled.label`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 13px;
  line-height: 16px;
  color: #4f566b;
  margin-bottom: 6px;
  display: block;
  span {
    color: red;
  }
`;
const RightWrapper = styled.div`
  margin-left: 340px;
`;
const HeaderWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  background: #fff;
  position: sticky;
  top: 1px;
  z-index: 99;
  padding: 40px 0px 10px 0px;
  flex-direction: column;
  svg {
    cursor: pointer;
  }
`;
const HeaderBlock = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 20px;
`;
const ItemLeft = styled.div``;
const HeaderHeading = styled.h2`
  font-family: Inter;
  font-style: normal;
  font-weight: bold;
  font-size: 24px;
  line-height: 32px;
  color: #1a1f36;
  margin: 0;
`;
const ItemRightWraper = styled.div`
  display: flex;
  align-items: center;
  margin-right: 5%;
`;
const GalleryMultiPhoto = styled.div`
  width: 100%;
  border-radius: 5px;
  display: flex;
  height: fit-content;
  flex-wrap: wrap;
  .plusicon {
    border-radius: 5px;
  }
`;
const Textarea = styled.textarea`
  background: #ffffff;
  border: 1px solid #e3e8ee;
  border-radius: 5px;
  width: 100%;
  outline: 0;
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  line-height: 18px;
  color: rgba(26, 31, 54, 1);
  resize: none;
  min-height: 130px;
  max-height: 130px;
  overflow-x: auto;
  margin-top: 6px;
  padding: 12px 16px;
  transition: 0.3s all ease;
  &::placeholder {
    color: rgba(26, 31, 54, 0.25);
  }
  :hover {
    border: 1px solid #c5c8cd;
  }
  :focus {
    border: 1px solid #c5c8cd;
    outline: 0;
  }
  :active {
    border: 1px solid #c5c8cd;
  }
`;
const OverViewPhotosBlock = styled.div`
  width: 100%;
  max-width: 40%;
  margin-left: 35px;
  margin-right: 60px;
  ${(props) =>
    props.disableDiv &&
    css`
      pointer-events: none;
      opacity: 0.7;
    `}
`;
const PhotoBlock = styled.div`
  border: 1px solid #e3e8ee;
  border-radius: 5px;
  padding: 8px;
  width: 380px;
  height: 419px;
  position: relative;
  .removeicon {
    position: absolute;
    bottom: 18px;
    right: 18px;
  }
`;
const PhotoAddMini = styled.img`
  border-radius: 5px;
  width: 364px;
  height: 403px;
`;
const PhotoBlockMini = styled.div`
  margin: 0px -9px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  position: relative;
`;
const MiniBlock = styled.div`
  display: flex;
  align-items: center;
  margin-top: 12px;
  width: 380px;
  .plusicon {
    width: 80px;
    height: 80px;
  }
`;

const FirstRow = styled.div`
  width: 100%;
  display: flex;
`;
const Second = styled.div`
  max-width: 50%;
  width: 100%;
`;
const ThirdRow = styled.div`
  max-width: 50%;
`;

class AddProduct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      oriPrice: '',
      selPrice: '',
      quantityAvailable: '',
      maxQuantity: '',
      categoryName: '',
      description: '',
      file: ''
    };
  }

  handleChange = (key, value) => {
    this.props.clearResponseMessage();
    if (!key) return;
    this.setState({ [key]: value });
  };

  componentWillUnmount() {
    this.props.clearResponseMessage();
  }

  renderErrors() {
    const { resError } = this.props.message;
    if (resError) {
      return <Message text={resError} type={'error'} />;
    }
  }

  renderSuccess() {
    const { resSuccess } = this.props.message;
    if (resSuccess) {
      return <Message text={resSuccess} type={'success'} />;
    }
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { name, oriPrice, selPrice, quantityAvailable, maxQuantity, categoryName, description } = this.state;
    const formData = new FormData();
    formData.append('name', name);
    formData.append('oriPrice', oriPrice);
    formData.append('selPrice', selPrice);
    formData.append('quantityAvailable', quantityAvailable);
    formData.append('maxQuantity', maxQuantity);
    formData.append('categoryName', categoryName);
    formData.append('description', description);
    this.props.addProduct(formData);
  };
  render() {
    const { name, oriPrice, selPrice, quantityAvailable, maxQuantity, categoryName, description } = this.state;
    const { loading } = this.props.product;
    return (
      <>
        <NavBar expanded={'PRODUCT'} />
        <RightWrapper>
          <HeaderWrapper>
            <HeaderBlock>
              <ItemLeft>
                <HeaderHeading>Add Product</HeaderHeading>
              </ItemLeft>
              <ItemRightWraper>
                <div className={classNames('btn-save-loading', { loading: loading })}>
                  <Button
                    small
                    disabled={false}
                    isPrimary={true}
                    type={'submit'}
                    title={'Save'}
                    onClick={this.handleSubmit}
                  />
                </div>
              </ItemRightWraper>
            </HeaderBlock>
          </HeaderWrapper>
          {this.renderErrors()}
          {this.renderSuccess()}
          <form onSubmit={this.handleSubmit}>
            <FirstRow>
              <Second>
                <InputBlockWrap>
                  <InputBlock>
                    <LabelForm>Product Name</LabelForm>
                    <Input
                      autoFocus={true}
                      newinventory
                      name={'name'}
                      placeholder={'name'}
                      value={name}
                      type={'text'}
                      onChange={(e) => {
                        this.handleChange('name', e.target.value);
                      }}
                    />
                  </InputBlock>
                </InputBlockWrap>

                <InputBlockWrap>
                  <InputBlock>
                    <LabelForm>Original Price</LabelForm>
                    <Input
                      newinventory
                      name={'oriPricename'}
                      placeholder={'original Price'}
                      value={oriPrice}
                      type={'number'}
                      onChange={(e) => {
                        this.handleChange('oriPrice', e.target.value);
                      }}
                    />
                  </InputBlock>
                </InputBlockWrap>
                <InputBlockWrap>
                  <InputBlock>
                    <LabelForm>Selling Price</LabelForm>
                    <Input
                      autoFocus={true}
                      newinventory
                      name={'selPrice'}
                      placeholder={'selling Price'}
                      value={selPrice}
                      type={'number'}
                      onChange={(e) => {
                        this.handleChange('selPrice', e.target.value);
                      }}
                    />
                  </InputBlock>
                </InputBlockWrap>
                <InputBlockWrap>
                  <InputBlock>
                    <LabelForm>Quantity Available</LabelForm>
                    <Input
                      newinventory
                      name={'quantityAvailable'}
                      placeholder={'Quantity Available'}
                      value={quantityAvailable}
                      type={'number'}
                      onChange={(e) => {
                        this.handleChange('quantityAvailable', e.target.value);
                      }}
                    />
                  </InputBlock>
                </InputBlockWrap>
                <InputBlockWrap>
                  <InputBlock>
                    <LabelForm>Max Order Quantity</LabelForm>
                    <Input
                      autoFocus={true}
                      newinventory
                      name={'maxQuantity'}
                      placeholder={'Max Quantity'}
                      value={maxQuantity}
                      type={'number'}
                      onChange={(e) => {
                        this.handleChange('maxQuantity', e.target.value);
                      }}
                    />
                  </InputBlock>
                </InputBlockWrap>
                <InputBlockWrap>
                  <InputBlock>
                    <LabelForm>Product Category</LabelForm>
                    <Input
                      newinventory
                      name={'categoryName'}
                      placeholder={'Category Name'}
                      value={categoryName}
                      type={'text'}
                      onChange={(e) => {
                        this.handleChange('categoryName', e.target.value);
                      }}
                    />
                  </InputBlock>
                </InputBlockWrap>
                <InputBlockWrap>
                  <InputBlock>
                    <LabelForm>Product Description</LabelForm>
                    <Textarea
                      name={`description`}
                      placeholder={'description'}
                      value={description}
                      type={'text'}
                      onChange={(e) => {
                        this.handleChange('description', e.target.value);
                      }}
                    />
                  </InputBlock>
                </InputBlockWrap>
              </Second>
              <ThirdRow>
                <OverViewPhotosBlock disableDiv={loading}>
                  <>
                    <PhotoBlock>
                      <PhotoAddMini src={LogoIcon} />
                      <RemoveIcon className='removeicon' onClick={this.removeImage} />
                    </PhotoBlock>
                    <MiniBlock>
                      <PhotoBlockMini>
                        <GalleryMultiPhoto>
                          {/* <SortableList items={gallery} onSortEnd={this.onSortEnd} axis='xy' /> */}
                        </GalleryMultiPhoto>
                      </PhotoBlockMini>
                      <Input
                        id='gallery'
                        style={{ display: 'none' }}
                        type='file'
                        onChange={this.onChangeGalleryPhoto}
                        accept='image/*'
                      />
                    </MiniBlock>
                  </>
                </OverViewPhotosBlock>
              </ThirdRow>
            </FirstRow>
          </form>
        </RightWrapper>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  product: state.product,
  message: state.message
});

export default connect(mapStateToProps, {
  addProduct,
  clearResponseMessage
})(AddProduct);
