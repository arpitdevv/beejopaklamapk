import React, { Component } from 'react';
import classNames from 'classnames';
import { connect } from 'react-redux';
import styled, { css } from 'styled-components';
import NavBar from '../../../components/NavBar/NavBar';
import { addCategory, getCategoryList } from '../../../services/productService';
import { ReactComponent as HorizantalIcon } from '../../../assets/images/svg/Horizantalmore.svg';
import Loading from '../../../components/Loading/Loading';
import Input from '../../../components/Input/Input';
import Message from '../../../components/Message';
import Button from '../../../components/Button/Button';
import { clearResponseMessage } from '../../../actions/messageActions';

const TableIt = styled.table`
  width: 100%;
  border-collapse: collapse;
`;
const Tr = styled.tr`
  &:first-child {
    border-top: 0;
  }
`;
const RightWrapper = styled.div`
  margin-left: 340px;
`;
const Th = styled.th`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 13px;
  line-height: 16px;
  color: #4f566b;
  text-align: left;
  padding: 10px 20px;
  &:first-child {
    padding-left: 8px;
  }
`;
const Td = styled.td`
  font-family: Inter;
  font-style: normal;
  font-weight: normal;
  font-size: 13px;
  line-height: 16px;
  color: #4f566b;
  padding: 20px;
  border-top: 1px solid #e3e8ee;
  border-bottom: 1px solid #e3e8ee;
  &.Workbookright {
    text-align: left;
  }
  &:last-child {
    text-align: right;
    padding: 0 8px 0 0;
    cursor: pointer;
  }
  &:first-child {
    padding-left: 8px;
  }
`;
const HeaderWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  background: #fff;
  position: sticky;
  top: 1px;
  z-index: 99;
  padding: 40px 0px 10px 0px;
  flex-direction: column;
  svg {
    cursor: pointer;
  }
`;
const HeaderBlock = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 20px;
`;
const ItemLeft = styled.div``;
const HeaderHeading = styled.h2`
  font-family: Inter;
  font-style: normal;
  font-weight: bold;
  font-size: 24px;
  line-height: 32px;
  color: #1a1f36;
  margin: 0;
`;
const ItemRightWraper = styled.div`
  margin-right: 5%;
  display: flex;
  align-items: center;
`;
const InputBlockWrap = styled.div`
  width: 100%;
  max-width: 50%;
  padding: 0 10px;
  ${(props) =>
    props.formboxone &&
    css`
      padding-left: 0px;
    `}
  ${(props) =>
    props.formboxotwo &&
    css`
      padding-right: 0px;
    `}
`;
const InputBlock = styled.div`
  margin-bottom: 20px;
  input {
    margin-bottom: 0px;
  }
  input::placeholder {
    font-family: Inter;
    font-style: normal;
    font-weight: 500;
    font-size: 15px;
    line-height: 18px;
    color: rgba(26, 31, 54, 0.25);
  }
`;
const LabelForm = styled.label`
  font-family: Inter;
  font-style: normal;
  font-weight: 500;
  font-size: 13px;
  line-height: 16px;
  color: #4f566b;
  margin-bottom: 6px;
  display: block;
  span {
    color: red;
  }
`;
class CategoryList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      categoryName: ''
    };
  }

  componentDidMount() {
    this.loadData();
  }

  loadData = () => {
    this.props.getCategoryList();
  };

  handleChange = (key, value) => {
    this.props.clearResponseMessage();
    if (!key) return;
    this.setState({ [key]: value });
  };

  renderErrors() {
    const { resError } = this.props.message;
    if (resError) {
      return <Message text={resError} type={'error'} />;
    }
  }

  renderSuccess() {
    const { resSuccess } = this.props.message;
    if (resSuccess) {
      return <Message text={resSuccess} type={'success'} />;
    }
  }

  handleSubmit = () => {
    const reqData = this.state;
    const res = this.props.addCategory(reqData);
    if (res === true) {
      this.setState({ categoryName: '' });
      this.loadData();
    }
  };

  render() {
    const { categoryName } = this.state;
    const { categoryList, loading } = this.props.product;
    return (
      <>
        <NavBar expanded={'PRODUCT'} />
        <RightWrapper>
          <HeaderWrapper>
            <HeaderBlock>
              <ItemLeft>
                <HeaderHeading>Category List</HeaderHeading>
              </ItemLeft>
              <ItemRightWraper>
                <div className={classNames('btn-save-loading', { loading: loading })}>
                  <Button
                    small
                    disabled={false}
                    isPrimary={true}
                    type={'submit'}
                    title={'Add Category'}
                    onClick={this.handleSubmit}
                  />
                </div>
              </ItemRightWraper>
            </HeaderBlock>
          </HeaderWrapper>
          {this.renderErrors()}
          {this.renderSuccess()}
          <InputBlockWrap formboxone>
            <InputBlock>
              <LabelForm>
                Category Name<span>*</span>
              </LabelForm>
              <Input
                autoFocus={true}
                newinventory
                name={'categoryName'}
                placeholder={'name'}
                value={categoryName}
                type={'text'}
                onChange={(e) => {
                  this.handleChange('categoryName', e.target.value);
                }}
              />
            </InputBlock>
          </InputBlockWrap>
          {loading ? (
            <Loading />
          ) : (
            <TableIt>
              <Tr>
                <Th>Name</Th>
              </Tr>
              {categoryList &&
                categoryList.map((item) => (
                  <Tr key={item._id}>
                    <Td>{item.category}</Td>
                    <Td>
                      <HorizantalIcon />
                    </Td>
                  </Tr>
                ))}
            </TableIt>
          )}
        </RightWrapper>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  product: state.product,
  message: state.message
});

export default connect(mapStateToProps, {
  getCategoryList,
  clearResponseMessage,
  addCategory
})(CategoryList);
