import React, { Component } from 'react';
import NavBar from '../../../components/NavBar/NavBar';

class AddCategory extends Component {
  render() {
    return <NavBar expanded={'PRODUCT'} />;
  }
}

export default AddCategory;
