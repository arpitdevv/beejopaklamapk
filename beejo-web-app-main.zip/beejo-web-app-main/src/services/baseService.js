/**
 * @desc  Load required data
 */
export const loadRequiredData = (history) => async (dispatch, getState) => {
  try {
    console.log('user');
    return true;
  } catch (e) {
    return false;
  } finally {
  }
};
