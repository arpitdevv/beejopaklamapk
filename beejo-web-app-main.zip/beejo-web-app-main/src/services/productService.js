import axios from 'axios';
import { setErrorMessage, setSuccessMessage } from '../actions/messageActions';
import { clearProductResponseMessage, setCategoryList, setProductLoader } from '../actions/productAction';
const baseUrl = `https://beejo-app.herokuapp.com`;
const token =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2MGFjOGY0YmMwYzZmZTAwMTdiNThlMzEiLCJuYW1lIjoia3VsZGVlcCBwYXRlbCIsImlhdCI6MTYyMjM2NzU2MCwiZXhwIjoxNjUzOTAzNTYwfQ.YBBin0wrLP0PCYTpIqJcWqeSaNJTvpNnbCI9IjkbJzg';
/**
 * @desc  Add product
 * @param {*} obj Product For Add, Object
 */
export const addProduct = (obj) => async (dispatch) => {
  try {
    dispatch(clearProductResponseMessage());
    dispatch(setProductLoader(true));
    const headers = {
      'Content-Type': 'multipart/form-data; boundary=<calculated when request is sent>',
      Authorization: `Bearer ${token}`
    };
    const response = await axios.post(`${baseUrl}/admin/addProduct?lang=en`, obj, {
      method: 'POST',
      headers: headers
    });
    dispatch(setSuccessMessage(response.data.data));
    return true;
  } catch (e) {
    console.log('e', e);
    dispatchProductError('Something goes wrong, please try again later', dispatch);
    return undefined;
  } finally {
    dispatch(setProductLoader(false));
  }
};

/**
 * @desc  Get Category Listing
 */
export const getCategoryList = () => async (dispatch) => {
  try {
    dispatch(clearProductResponseMessage());
    dispatch(setProductLoader(true));
    const headers = { Authorization: `Bearer ${token}` };
    const response = await axios.get(`${baseUrl}/admin/category?lang=en`, {
      method: 'GET',
      headers: headers
    });
    const { data } = response;
    dispatch(setCategoryList(data.data));
    return true;
  } catch (e) {
    console.log('e', e);
    dispatchProductError('Something goes wrong, please try again later', dispatch);
    return false;
  } finally {
    dispatch(setProductLoader(false));
  }
};

/**
 * @desc  Add Category
 * @param {*} obj Category For Add Object
 */
export const addCategory = (obj) => async (dispatch) => {
  try {
    dispatch(clearProductResponseMessage());
    dispatch(setProductLoader(true));
    const headers = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    };
    const response = await axios.post(`${baseUrl}/admin/category?lang=en`, obj, {
      method: 'POST',
      headers: headers
    });
    if (response) {
      dispatch(setSuccessMessage(response.data.data));
      return true;
    }
  } catch (e) {
    console.log('e', e);
    dispatchProductError('Something goes wrong, please try again later', dispatch);
    return undefined;
  } finally {
    dispatch(setProductLoader(false));
  }
};

function dispatchProductError(msg, dispatch) {
  dispatch(setErrorMessage(msg));
}
