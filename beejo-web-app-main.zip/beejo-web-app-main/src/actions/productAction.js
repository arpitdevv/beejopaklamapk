import * as actions from './types';

/**
 * @desc Set Product Loader
 */
export const setProductLoader = (payload) => {
  return {
    type: actions.SET_PRODUCT_LOADER,
    payload: payload
  };
};

/**
 * @desc Set Product Category
 */
export const setCategoryList = (payload) => {
  return {
    type: actions.SET_CATEGORY_LIST,
    payload: payload
  };
};

/**
 * @desc Set Product Response Success
 */
export const setProductResponseSuccess = () => {
  return {
    type: actions.GET_PRODUCT_RES_SUCCESS
  };
};

/**
 * @desc Set Product Response Errors
 */
export const setProductResponseError = (payload) => {
  let resError = {};
  resError[payload.field] = payload.msg;
  return {
    type: actions.GET_PRODUCT_RES_ERROR,
    payload: resError
  };
};

/**
 * @desc Clear Product Response Message
 */
export const clearProductResponseMessage = () => {
  return {
    type: actions.CLEAR_PRODUCT_RES_MSG
  };
};
