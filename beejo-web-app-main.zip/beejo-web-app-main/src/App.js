/* eslint-disable import/no-unresolved */
import React, { Component } from 'react';
import { Router, Route, Switch } from 'react-router-dom';
import { Provider } from 'react-redux';
import history from './history';
import './App.scss';
import routes from './routes';
import { isDev } from './helper/common';
import { setupToken } from './helper/authTokenHelpers';
import store from './store/store';
import { loadRequiredData } from './services/baseService';
import PrivateRoutes from './components/PrivateRoutes';
import Loading from './components/Loading/Loading';

const token = setupToken();

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true
    };
  }

  componentDidMount() {
    if (isDev()) {
      console.log('Development');
    }
    this.loadData();
  }

  loadData = async () => {
    try {
      if (token) {
        await store.dispatch(loadRequiredData(history));
      }
    } catch (e) {
      console.log('ERROR', e);
    } finally {
      this.setState({ loading: false });
    }
  };

  render() {
    const { loading } = this.state;
    if (loading) {
      return <Loading />;
    }
    const routeComponents = routes.map((r, i) => {
      if (r.private) {
        return <PrivateRoutes key={i} {...r} />;
      } else {
        return <Route key={i} {...r} />;
      }
    });

    return (
      <Provider store={store}>
        <Router history={history}>
          <>
            <Switch>{routeComponents}</Switch>
          </>
        </Router>
      </Provider>
    );
  }
}
export default App;
