import Home from './Pages/Home/Home';
import Login from './Pages/MemberShip/Login/Login';
import AddCategory from './Pages/Product/AddCategory/AddCategory';
import AddProduct from './Pages/Product/AddProduct/AddProduct';
import CategoryList from './Pages/Product/CategoryList/CategoryList';

/**
 * Routes Array
 * Same properties should match for all attributes
 */
const routes = [
  {
    path: '/login',
    exact: true,
    component: Login,
    private: false
  },
  {
    path: '/',
    exact: true,
    component: Home,
    private: false
  },
  {
    path: '/home',
    exact: true,
    component: Home,
    private: false
  },
  {
    path: '/addproduct',
    exact: true,
    component: AddProduct,
    private: false
  },
  {
    path: '/addcategory',
    exact: true,
    component: AddCategory,
    private: false
  },
  {
    path: '/categorylist',
    exact: true,
    component: CategoryList,
    private: false
  }
];

export default routes;
